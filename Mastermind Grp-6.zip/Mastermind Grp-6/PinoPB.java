
/*cria um pino de análise sem ação de click*/
import java.awt.event.ActionEvent;

public class PinoPB extends Pino {

  public PinoPB() {
    super();
  }

  @Override
  public void acaoDoBotao(ActionEvent e) {
  }
}